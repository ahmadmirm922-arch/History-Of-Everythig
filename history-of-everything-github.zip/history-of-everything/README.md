# History of Everything

A responsive, static history-exploration website built with HTML, CSS and vanilla JavaScript.

## Features
- Search sample historical stories
- Browse World History, Indian History, Inventions and Places categories
- Filter a sample timeline by era
- Open story detail popups
- Toggle between dark and light themes
- Responsive layout for phones, tablets and desktops

## Run locally
1. Download and unzip this project.
2. Open the `history-of-everything` folder.
3. Double-click `index.html` to open it in your browser.

For a local development server, you can also use the VS Code **Live Server** extension.

## Publish with GitHub Pages
1. Sign in to GitHub and create a new repository, for example `history-of-everything`.
2. Upload `index.html`, `style.css`, `script.js` and `README.md` to the repository root.
3. Open the repository's **Settings**.
4. Select **Pages** from the left menu.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select branch `main` and folder `/ (root)`, then click **Save**.
7. Wait a few minutes. GitHub will show your published website URL in the Pages section.

## Customising the content
The example historical entries are in `script.js` inside the `events` array. Add or edit entries there. Each entry has:
- `year`: date or period
- `era`: `Ancient`, `Medieval` or `Modern`
- `title`: story heading
- `category`: category name
- `text`: short description

## Important note
This is a front-end starter project with sample content. It does not yet connect to a live history database, map service, user accounts or AI search. Check facts with reliable sources before publishing expanded historical content.
