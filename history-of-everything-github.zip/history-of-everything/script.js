const events = [
 {year:"c. 3100 BCE",era:"Ancient",title:"The first Egyptian dynasty",category:"World History",text:"Ancient Egypt developed along the Nile. Around this period, Upper and Lower Egypt were traditionally united under early kings, marking the beginning of dynastic rule."},
 {year:"c. 2600 BCE",era:"Ancient",title:"The Great Pyramid of Giza",category:"Places",text:"The Great Pyramid was built as a royal tomb for Pharaoh Khufu. It became the only surviving wonder of the traditional Seven Wonders of the Ancient World."},
 {year:"c. 2600 BCE",era:"Ancient",title:"Indus Valley cities flourish",category:"Indian History",text:"Cities such as Harappa and Mohenjo-daro developed planned streets, drainage systems and sophisticated craft traditions in the Indus Valley."},
 {year:"c. 500 BCE",era:"Ancient",title:"The age of new ideas",category:"World History",text:"Across several regions, influential philosophical and religious traditions took shape, including teachings associated with the Buddha and Mahavira in South Asia."},
 {year:"0–100 CE",era:"Ancient",title:"The Roman world",category:"World History",text:"The Roman Empire connected a vast territory through roads, trade, law and urban life, leaving a deep legacy in Europe and the Mediterranean."},
 {year:"1206",era:"Medieval",title:"The Delhi Sultanate begins",category:"Indian History",text:"Qutb al-Din Aibak established the Mamluk dynasty in Delhi, beginning a succession of Sultanate dynasties that shaped much of northern India."},
 {year:"1450s",era:"Medieval",title:"Printing transforms communication",category:"Inventions",text:"Johannes Gutenberg's movable-type printing system helped make books more widely available in Europe and accelerated the spread of ideas."},
 {year:"1498",era:"Medieval",title:"Vasco da Gama reaches India by sea",category:"Indian History",text:"The Portuguese navigator arrived at Calicut on the Malabar Coast, opening a new direct sea route between Europe and the Indian Ocean trading world."},
 {year:"1757",era:"Modern",title:"Battle of Plassey",category:"Indian History",text:"The East India Company's victory at Plassey marked a major turning point in its rise to political power in Bengal and the Indian subcontinent."},
 {year:"1760s",era:"Modern",title:"The Industrial Revolution",category:"Inventions",text:"New machines, factories and energy systems transformed production and transport, first in Britain and then across many parts of the world."},
 {year:"1947",era:"Modern",title:"India becomes independent",category:"Indian History",text:"British colonial rule ended on 15 August 1947. The independence of India was accompanied by the Partition of British India."},
 {year:"1969",era:"Modern",title:"Humans reach the Moon",category:"Inventions",text:"Apollo 11 landed on the Moon in July 1969. Neil Armstrong and Buzz Aldrin walked on its surface while Michael Collins orbited above."},
 {year:"1983",era:"Modern",title:"The modern internet takes shape",category:"Inventions",text:"The ARPANET adopted TCP/IP on 1 January 1983, a key milestone in the development of the interconnected internet."},
 {year:"1991",era:"Modern",title:"The World Wide Web opens to the public",category:"Inventions",text:"The Web, invented by Tim Berners-Lee, became publicly accessible beyond CERN in 1991 and changed how people share and find information."}
];

const list = document.getElementById("timelineList");
const modal = document.getElementById("modal");
function render(items) {
  list.innerHTML = "";
  if (!items.length) {
    list.innerHTML = '<p class="empty-state">No matching stories found. Try another search.</p>';
    return;
  }
  items.forEach((item) => {
    const card = document.createElement("article");
    card.className = "event-card";
    card.tabIndex = 0;
    card.setAttribute("role", "button");
    card.innerHTML = `<div><div class="event-year">${item.year}</div><div class="event-era">${item.era.toUpperCase()}</div></div><div><h3>${item.title}</h3><p>${item.text}</p><span class="read-more">READ THE STORY ↗</span></div>`;
    const open = () => showDetail(item);
    card.addEventListener("click", open);
    card.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); open(); } });
    list.appendChild(card);
  });
}
function showDetail(item) {
  document.getElementById("modalEra").textContent = `${item.category} / ${item.era}`;
  document.getElementById("modalTitle").textContent = item.title;
  document.getElementById("modalDate").textContent = item.year;
  document.getElementById("modalText").textContent = item.text;
  modal.classList.add("open");
  modal.setAttribute("aria-hidden", "false");
}
function closeModal() { modal.classList.remove("open"); modal.setAttribute("aria-hidden", "true"); }
document.getElementById("modalClose").addEventListener("click", closeModal);
modal.addEventListener("click", e => { if (e.target === modal) closeModal(); });
document.addEventListener("keydown", e => { if (e.key === "Escape") closeModal(); });
function search(term) {
  const q = term.trim().toLowerCase();
  const matches = events.filter(e => `${e.title} ${e.text} ${e.category} ${e.era} ${e.year}`.toLowerCase().includes(q));
  render(matches);
  document.getElementById("timeline").scrollIntoView({behavior:"smooth"});
}
document.getElementById("searchForm").addEventListener("submit", e => { e.preventDefault(); search(document.getElementById("searchInput").value); });
document.querySelectorAll("[data-search]").forEach(b => b.addEventListener("click", () => { document.getElementById("searchInput").value = b.dataset.search; search(b.dataset.search); }));
document.querySelectorAll("[data-category]").forEach(b => b.addEventListener("click", () => search(b.dataset.category)));
document.getElementById("filters").addEventListener("click", e => {
  const button = e.target.closest("[data-filter]");
  if (!button) return;
  document.querySelectorAll(".filter").forEach(b => b.classList.remove("active"));
  button.classList.add("active");
  render(button.dataset.filter === "All" ? events : events.filter(x => x.era === button.dataset.filter));
});
document.getElementById("themeToggle").addEventListener("click", () => document.body.classList.toggle("light"));
document.getElementById("year").textContent = new Date().getFullYear();
render(events);
